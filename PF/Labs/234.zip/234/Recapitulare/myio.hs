newtype MyIO a = MyIO { runIO :: String -> (a, String, String) }
--                               ^^^input       ce-a ramas din input,

getChar' :: MyIO Char
getChar' = MyIO (\input -> 
            if input == "" 
                then error "No input"
                else let (head:tail) = input in (head, tail, ""))

-- se pronunta unit = ()
putChar' :: Char -> MyIO ()
putChar' c  = MyIO (\input -> ((), input, c:""))

getLine'' :: MyIO String 
getLine'' = MyIO 
    (\input -> 
        let (caracter, input2, niste_output1) = runIO getChar' input in
                           if caracter == '\n'
                                then (caracter:"", input2, niste_output1)
                                else 
                                    let (rand, input3, niste_output2) = runIO getLine' input2 in 
                                    (caracter:rand, input3, niste_output1 ++ niste_output2))
                                       
instance Functor MyIO where 
    fmap functie (MyIO action) =
        MyIO (\input -> let (elem, input_nou, niste_output) = action input in 
                        (functie elem, input_nou, niste_output))

instance Monad MyIO where
    (MyIO plan_care_intoarce_elem) >>= functie =
        MyIO (\input -> let (elem, input2, niste_output1) = plan_care_intoarce_elem input in
                        let MyIO plan2 = functie elem in 
                        let (elem_final, input_final, inca_niste_output) = plan2 input2 in 
                        (elem_final, input_final, niste_output1 ++ inca_niste_output))

    return x = MyIO (\input -> (x, input, ""))

instance Applicative MyIO where 
    pure = return 
    cf <*> ce = do
        f <- cf
        e <- ce
        return (f e)

getLine' = do 
    c <- getChar'
    if c == '\n' 
        then 
            return ("")
        else do
            restul <- getLine' 
            return (c:restul)

run :: MyIO () -> String -> String
run plan input = let (_, _, output) = runIO plan input in output

readLn' :: Read a => MyIO a
readLn' = do 
    a <- getLine' 
    return (read a)

read_n_numbers :: Int -> MyIO Int
read_n_numbers 0 = pure 0 
read_n_numbers n = do 
    a <- read_n_numbers (n - 1)
    actual <- readLn' 
    return (a + actual)

putLine' :: String -> MyIO ()
putLine' "" = putChar' '\n'
putLine' (h:t) = do 
    putChar' h
    putLine' t

printLn' :: Show a => a -> MyIO ()
printLn' x = do
    let s = show x 
    putLine' s 

main' = do 
    n <- readLn'
    suma <- read_n_numbers n 
    printLn' suma

data Expr a = Valoare a | (Expr a) :+: (Expr a) | (Expr a) :*: (Expr a) | (Expr a) :-: (Expr a)

infixl 1 :+:
infixl 3 :*: 

instance Show a => Show (Expr a) where
    show (Valoare x) = show x 
    show (x :+: y) = "(" ++ show x ++ " + " ++ show y ++ ")"
    show (x :*: y) = show x ++ " * " ++ show y
    show (x :-: y) = "(" ++ show x ++ " - " ++ show y ++ ")"

test_show1 = show (5 :+: (3 :*: 7)) == "(5 + 3 * 7)"

instance Num a => Num (Expr a) where 
    fromInteger x = Valoare (fromInteger x)

    x + y = x :+: y 
    x - y = x :-: y
    x * y = x :*: y
    abs x = x
    signum x = x

instance Foldable Expr where 
    foldr functie accum (Valoare x) = functie x accum 
    foldr functie accum (x :+: y)= let nou_accum = foldr functie accum y in
                                    foldr functie nou_accum x
    foldr functie accum (x :*: y) = foldr functie accum (x :+: y)
    foldr functie accum (x :-: y) = foldr functie accum (x :+: y)

    foldMap functie (Valoare x) = functie x 
    foldMap functie (x :+: y) = (foldMap functie x) <> (foldMap functie y)
    foldMap functie (x :*: y) = (foldMap functie x) <> (foldMap functie y)
    foldMap functie (x :-: y) = (foldMap functie x) <> (foldMap functie y)

data Suma = S Int  deriving(Show)

instance Semigroup Suma where 
    (S x) <> (S y) = S (x + y)

data Produs = P Int  deriving(Show)

instance Semigroup Produs where 
    (P x) <> (P y) = P (x * y)

instance Monoid Suma where 
    mempty = S 0

instance Monoid Produs where 
    mempty = P 1

foldr' :: Foldable f => (a -> b -> b) -> b -> f a -> b
foldr' functie accum container = 
  let l = foldMap (\x -> [x]) container in 
  foldr functie accum l 

data Auxiliar accum = Functie (accum -> accum)

instance Semigroup (Auxiliar accum) where 
    (Functie f1) <> (Functie f2) = Functie (f1 . f2)

instance Monoid (Auxiliar accum) where 
    mempty = Functie id 

foldr'' :: Foldable f => (a -> b -> b) -> b -> f a -> b
foldr'' functie accum container = 
    let Functie final = foldMap (\x -> Functie (\accum -> functie x accum)) container in 
    final accum 


