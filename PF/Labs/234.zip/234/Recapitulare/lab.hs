-- f compus cu g -> f(g(x))
-- g : A -> B
-- f : B -> C
-- (f . g) : A -> C
--
-- (f.g)(x) = f(g(x))
compunere :: (b -> c) -> (a -> b) -> (a -> c)
-- (b -> c) -> (a -> b) -> a -> c
compunere f g = (\x -> f $ g x)
compunere' f g = (\x -> let y = g x in f y)
compunere'' f g x = f (g x)

data Lista a = Goala | Ceva a (Lista a)

-- constructori de date
-- Goala 
-- Ceva 
-- constructor de tipuri
-- Lista

f :: Int -> Int -> Int 
f x y = x + y
-- f x Int = 
instance Show a => Show (Lista a) where 
    show Goala = "[]"
    show (Ceva head tail) = show head ++ ":" ++ show tail
    
--min2 :: Ord a => a -> a -> a
min2 x y = if x < y then x else y


data Joc = Piatra | Foarfece | Hartie

data Tuplu a = Nimic | Singur a | Pereche a a | Triplet a a a

data TipulMeuSpecial = ConstructorGoi | ConstructorCu2Parametri Int Float | Int :++*+: Float 

data Lista' a = Nil | a ::: (Lista' a)

infixr 7 ::: 

instance Show a => Show (Lista' a) where 
    show Nil = "[]"
    show (head ::: tail) = show head ++ ":" ++ show tail

sumaimpare [] = 0
sumaimpare [x] = x
sumaimpare (h1:h2:t) = h1 + sumaimpare t
-- (sumaimpare h1):h2:t <-> foarte rau
--
sumaimpare' lista = sum [x| (x, pos) <- zip lista [1..], odd pos]
sumaimpare'' lista = sum $ map fst (filter (odd.snd) $ zip lista [1..])

instance Functor Lista' where
    fmap _ Nil = Nil 
    fmap f (head:::tail) = (f head) ::: (fmap f tail)

data Cutie a = Cutie a Int deriving(Show)

cutie elem = Cutie elem 0

instance Functor Cutie where 
    fmap f (Cutie elem count) = Cutie (f elem) (count + 1)



Nil +++ x = x 
(h ::: t) +++ x = h ::: (t +++ x)

instance Applicative Lista' where 
    pure elem = elem ::: Nil 

    Nil <*> _ = Nil 
    (head_functii ::: tail_functii) <*> elemente = 
        let prima_bucata = fmap head_functii elemente in 
        let restul = tail_functii <*> elemente in 
        prima_bucata +++ restul

produs_magic f cutia1 cutia2 = pure f <*> cutia1 <*> cutia2

instance Monad Lista' where 
    Nil >>= _ = Nil 
    (head ::: tail) >>= f = 
        let rezultat = f head in 
        let restul = tail >>= f in 
        rezultat +++ restul

scoate_din_scoarta cutie = do 
    x <- cutie 
    x
scoate_din_scoarte cutie = cutie >>= (\x -> x)

instance Monad Cutie where
    (Cutie elem count) >>= f = 
        let Cutie final count_nou = f elem in 
        Cutie final (count_nou + count + 1)
    return = cutie 

instance Applicative Cutie where
    pure = return 
    cutie_f <*> cutie_e = do 
        f <- cutie_f 
        e <- cutie_e 
        return (f e)

dublu cutie = do 
    x <- cutie 
    return (2 * x)

ddublu :: Cutie Int -> Cutie Int 
ddublu cutie = dublu (dublu cutie)
